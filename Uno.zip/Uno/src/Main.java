public class Main {
    public static void main(String[] args) {

        Game game1 = new Game(new String[]{"player1", "player2", "player3", "player4"});
        game1.start(game1);
        game1.getPlayerHand("player1");
        game1.hasEmptyHand("player1");
        game1.getCurrentPlayer();
        game1.getPreviousPlayer(2);
        game1.getTopCard();
    }
}