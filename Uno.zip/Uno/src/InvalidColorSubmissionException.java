import javax.swing.*;

public class InvalidColorSubmissionException extends Exception{
    private UnoCard.Color expected;
    private UnoCard.Color actual;

    public InvalidColorSubmissionException(JLabel message, UnoCard.Color actual, UnoCard.Color expected){
        this.actual = actual;
        this.expected = expected;
    }
}
