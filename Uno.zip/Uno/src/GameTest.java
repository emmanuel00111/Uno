import org.junit.jupiter.api.*;
import static org.junit.jupiter.api.Assertions.*;
public class GameTest {
    private static Game game1;
    private static int counter;
    private UnoDeck deck;
    private UnoCard.Color validColor;
    private UnoCard.Value validValue;
    @BeforeAll
    private static void setup(){
        game1 = null;
    }
    @AfterEach
    private void summary(){
        counter+=1;
    }
    @AfterAll
    private static void tearDown(){
        System.out.println("Tests passed " + counter);
        System.out.println("All tests are done");
    }
    @Test
    public void test_CurrentPlayer(){
        game1 = new Game(new String[]{"player1", "player2", "player3", "player4"});
        assertEquals(game1.getCurrentPlayer(), "player1");
    }
    @Test
    public void test_PreviousPlayer(){
        game1 = new Game(new String[]{"player1", "player2", "player3", "player4"});
        game1.getCurrentPlayer();
        assertEquals(game1.getPreviousPlayer(1), "player4");
    }
    @Test
    public void test_PlayerHandSize() {
        game1 = new Game(new String[]{"player1", "player2", "player3", "player4"});
        assertEquals(game1.getPlayerHandSize("player1"), 7);
        assertEquals(game1.getPlayerHandSize("player2"), 7);
        assertEquals(game1.getPlayerHandSize("player3"), 7);
        assertEquals(game1.getPlayerHandSize("player4"), 7);
    }
    @Test
    public void test_HasEmptyHand() {
        game1 = new Game(new String[]{"player1", "player2", "player3", "player4"});
        assertEquals(game1.hasEmptyHand("player1"), false);
        assertEquals(game1.hasEmptyHand("player2"), false);
        assertEquals(game1.hasEmptyHand("player3"), false);
        assertEquals(game1.hasEmptyHand("player4"), false);
    }
    @Test
    public void test_GameOver(){
        game1 = new Game(new String[]{"player1", "player2", "player3", "player4"});
        assertEquals(game1.isGameOver(), false);
        //As there is no method to clear out a players hand (due to the laws of the game)
        //Manual testing would have to be implemented for when a hand is empty and the game is finished
    }
    @Test
    public void test_GameDirection() {
        game1 = new Game(new String[]{"player1", "player2", "player3", "player4"});
        assertEquals(game1.gameDirection, false);
    }

}
