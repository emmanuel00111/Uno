import javax.swing.*;

public class InvalidValueSubmissionException extends Exception{
    private UnoCard.Value expected;
    private UnoCard.Value actual;

    public InvalidValueSubmissionException(JLabel message, UnoCard.Value actual, UnoCard.Value expected){
        this.actual = actual;
        this.expected = expected;
    }
}
